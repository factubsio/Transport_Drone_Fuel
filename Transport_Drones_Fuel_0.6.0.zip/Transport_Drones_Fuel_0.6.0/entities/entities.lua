-- local require = function(name) return require("data/entities/"..name) end

require("transport_refinery/transport_refinery")
