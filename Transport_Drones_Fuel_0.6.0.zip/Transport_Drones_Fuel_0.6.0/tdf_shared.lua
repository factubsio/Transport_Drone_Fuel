local lib = {}
lib.fuel_name = "drone-fuel"

function lib.path(path)
    return "__Transport_Drones_Fuel__/" .. path
end

return lib